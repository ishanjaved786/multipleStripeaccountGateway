<?php 

/**
 * 
 */
class issfront
{
	
	function __construct()
	{

		//$this->Init();

	}


	public function Init(){

		//add_filter('wc_stripe_params ', array($this,'stripe_params'));
		add_action('wp', array($this, 'checkout_code'));
	}


	public function checkout_code(){
 
		
		if(is_checkout()){

			add_filter('wc_stripe_payment_request_params', array($this,'stripe_params_request'));

		}

	}


	public function stripe_params_request(){

		//echo "<pre>"; var_dump($params); echo "</pre>";

		$options['t1'] = get_option('iss_t1');
		$options['t2'] = get_option('iss_t2');

		return $options;

		//$this->condition_code($options);

	}



	public function variation_code($product_id,$options){

		$t1 = explode(',',  $options['t1']['t1vi']);
		$t2 = explode(',',  $options['t2']['t2vi']);

		if(in_array($product_id, $t1)){

			$data = $this->switch_keys($options, 't1');
			return $data;

		}else if(in_array($product_id, $t2)){

			$data = $this->switch_keys($options, 't2');	
			return $data;
		}


	}


	public function non_variation_code($product_id,$options){

		$t1 = explode(',',  $options['t1']['t1pi']);
		$t2 = explode(',',  $options['t2']['t2pi']);


		if(in_array($product_id, $t1)){

			$data = $this->switch_keys($options, 't1');
			return $data;

		}else if(in_array($product_id, $t2)){

			$data = $this->switch_keys($options, 't2');
			return $data;

		}else{
			
			
			//$term = get_term_by( 'id', $product_id, 'product_cat' );

			$t1cat = false;
			$t2cat = false;

			$terms = get_the_terms( $product_id, 'product_cat' );



			foreach ($terms as $term) {
			   
				if(!empty($options['t1']['t1select']) && in_array($term->slug, $options['t1']['t1select'])){

					$t1cat = true;
					break;
				}

				if(!empty($options['t2']['t2select']) && in_array($term->slug, $options['t2']['t2select'])){

					$t2cat = true;
					break;
				}

			}

			if($t1cat){

				$data = $this->switch_keys($options, 't1');
				return $data;

			}else if($t2cat){

				$data = $this->switch_keys($options, 't2');
				return $data;
				
			}
			
		}

	}


	public function switch_keys($options,$user){


		$st = get_option('woocommerce_stripe_settings');

		$test = false;

		if($st['testmode'] == 'yes'){ $test = true; }

		if($user == 't1'){

			if($test){

				$key['p'] = $options['t1']['t1public'];
				$key['l'] = $options['t1']['t1private'];

				return $key;

			}else{

				$key['p'] = $options['t1']['l1public'];	
				$key['l'] = $options['t1']['l1private'];	

				return $key;
			}

		}else if($user == 't2'){

			if($test){

				$key['p'] = $options['t2']['t2public'];
				$key['l'] = $options['t2']['t2private'];

				return $key;

			}else{

				$key['p'] = $options['t2']['l2public'];	
				$key['l'] = $options['t2']['l2private'];	

				return $key;
			}

		}

	}


	public function category_check_for_shipping($cat,$options){

			$t1cat = false;
			$t2cat = false;

			   
				if(in_array($cat, $options['t1']['t1select'])){

					$t1cat = true;

				}

				if(in_array($cat, $options['t2']['t2select'])){

					$t2cat = true;

				}

			if($t1cat){

				$data = $this->switch_keys($options, 't1');
				return $data;

			}else if($t2cat){

				$data = $this->switch_keys($options, 't2');
				return $data;
				
			}

	}


}

?>