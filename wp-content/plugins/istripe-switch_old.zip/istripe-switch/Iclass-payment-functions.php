<?php 


/**
 * 
 */
class isspaymentfunctions
{
	
	function __construct()
	{

	}

	public function create_token($args,$key,$amount,$product_id){

		$amount = $amount * 100;

		$token = \Stripe\Token::create([
			'card' => [
				'number' => $args['iss_No'],
				'exp_month' => $args['iss_month'],
				'exp_year' => $args['iss_year'],
				'cvc' => $args['iss_cvv']
			]
		],$key['p']);

		if(!empty($token['id'])){

			$charge = \Stripe\Charge::create([
				"amount" => $amount,
				"currency" => "usd",
	  		"source" => $token, // obtained with Stripe.js
	  		"description" => "Charge for ".$_POST['billing_email']." product_id ".$product_id
	  	],$key['l']);

			return $charge;

		}else{
			echo $token;
		}

		//echo $token['id'];
		//return $charge;


	}


	public function shipping_charge($args,$key,$amount){

		$amount = $amount * 100;

		$token = \Stripe\Token::create([
			'card' => [
				'number' => $args['iss_No'],
				'exp_month' => $args['iss_month'],
				'exp_year' => $args['iss_year'],
				'cvc' => $args['iss_cvv']
			]
		],$key['p']);

		if(!empty($token['id'])){

			$charge = \Stripe\Charge::create([
				"amount" => $amount,
				"currency" => "usd",
	  		"source" => $token, // obtained with Stripe.js
	  		"description" => "Charge for ".$_POST['billing_email']."  Shipping Charge"
	  	],$key['l']);

			return $charge;

		}else{
			echo $token;
		}

		//echo $token['id'];
		//return $charge;

	}


	public function subscription_payment($args,$key,$amount,$product_id,$order_id,$sub_id){

		$amount = $amount * 100;

		$token = \Stripe\Token::create([
			'card' => [
				'number' => $args['iss_No'],
				'exp_month' => $args['iss_month'],
				'exp_year' => $args['iss_year'],
				'cvc' => $args['iss_cvv']
			]
		],$key['p']);


		if(!empty($token['id'])){

			$customer = \Stripe\Customer::create([
				'source' => $token,
				'email' => $_POST['billing_email'],
			],$key['l']);

			if ($customer->id || !empty($customer->id)) {
				

				add_post_meta($sub_id, 'cid', $customer->id);

/*				$data_store = WC_Data_Store::load( 'order-item' );
				$meta_id    = $data_store->add_metadata( $item_id, 'cid', $customer->id, true );

				if ( $meta_id ) {
					
					WC_Cache_Helper::incr_cache_prefix( 'object_' . $item_id ); // Invalidate cache.
					//return $meta_id;
				}*/
				if(round($amount) == 0){
					$charge = array('status' => 'succeeded');
					return $charge;
				}else{

				$charge = \Stripe\Charge::create([
					"amount" => $amount,
					"currency" => "usd",
	  				"customer" => $customer->id, // obtained with Stripe.js
	  				"description" => "Charge for ".$product_id." from ".$_POST['billing_email']."  Total Subscription Amount Order Id ".$order_id
	  			],$key['l']);
				return $charge;
				}

			}else{
				echo $customer;
			}

		}else{
			echo $token;
		}


	}

		public function subscription_payment_renew($key,$amount,$product_id,$cid){

		$amount = $amount * 100;


				$charge = \Stripe\Charge::create([
					"amount" => $amount,
					"currency" => "usd",
	  				"customer" => $cid, // obtained with Stripe.js
	  				"description" => "Subscription renewal Charge for ".$product_id
	  			],$key['l']);

				return $charge;
	}


}