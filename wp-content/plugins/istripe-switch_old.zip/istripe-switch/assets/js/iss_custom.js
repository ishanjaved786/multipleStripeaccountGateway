jQuery(document).ready(function(){

jQuery('.sbtn').click(function(){

let fr = jQuery(this).parents('form').serialize();

if(jQuery(this).attr('name') == 't1iss'){

iss_formhandler(fr,'t1');

}else if(jQuery(this).attr('name') == 't2iss'){

iss_formhandler(fr,'t2');

}

return false;

});


jQuery('.t1select').select2();
jQuery('.t2select').select2();

jQuery('input[name=tabs]').click(function(){
jQuery('.t1select').select2();
jQuery('.t2select').select2();
})

});


function iss_formhandler(form,type) {

jQuery.ajax({

	url : aj.ajax_url,
	type : 'POST',
	data : {action : 'iss_data_update', data : form, type : type},
	success : function(response){
		console.log(response);
		if(response == 1){
			alert('Data updated !');
		}else{
			alert('Some error occured please refresh page and try again');
		}
	}
})

}
